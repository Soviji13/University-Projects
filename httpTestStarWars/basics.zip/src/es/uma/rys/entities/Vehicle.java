package es.uma.rys.entities;

// Class obtained when querying for a vehicle

public class Vehicle {
	public String name;
	public String model;
	public String vehicle_class;
	public String length;
	public String cost_in_credits;
	public String[] pilots;
}
