package es.uma.rys.entities;

// Class obtained when querying for a spaceship

public class SpaceShip {
	public String name;
	public String model;
	public String starship_class;
	public String cost_in_credits;
	public String length;
	public String[] pilots;
}
