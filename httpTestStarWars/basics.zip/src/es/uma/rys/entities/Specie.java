package es.uma.rys.entities;

// Class obtained when querying for a species

public class Specie {
	public String name;
	public String language;
	public String designation;
	public String[] people;
}
